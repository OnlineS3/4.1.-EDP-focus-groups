if(!Sanitize.Config) {
  Sanitize.Config = {}
}

Sanitize.Config.RESTRICTED = {
  elements: ['b', 'em', 'i', 'strong', 'u']       
}