<?php

class Toolset_Compatibility_Theme_avada extends Toolset_Compatibility_Theme_Handler{

    protected function run_hooks() {
        /**
         * For now Avada doesn't need any adjustments to be compatible with Layouts
         */
    }
}