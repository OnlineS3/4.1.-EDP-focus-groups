<?php
class Toolset_Compatibility_Theme_twenty_seventeen extends Toolset_Compatibility_Theme_Handler{


    protected function run_hooks() {

    }

}