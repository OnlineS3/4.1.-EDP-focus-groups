(function ($) {
  'use strict';
  DDLayout.views.ParentLayoutView = DDLayout.views.ContainerView.extend({

  });
})(jQuery)