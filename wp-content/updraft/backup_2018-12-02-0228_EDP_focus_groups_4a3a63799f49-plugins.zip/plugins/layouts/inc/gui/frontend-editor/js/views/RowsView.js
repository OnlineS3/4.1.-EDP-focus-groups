DDLayout.views.RowsView = DDLayout.views.abstract.CollectionView.extend({

});