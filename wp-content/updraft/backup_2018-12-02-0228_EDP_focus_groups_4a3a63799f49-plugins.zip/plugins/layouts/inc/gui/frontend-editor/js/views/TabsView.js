DDLayout.views.TabsView = DDLayout.views.ContainerView.extend({

});