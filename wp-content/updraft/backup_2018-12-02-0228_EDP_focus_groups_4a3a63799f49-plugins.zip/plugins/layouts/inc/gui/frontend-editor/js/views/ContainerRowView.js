DDLayout.views.ContainerRowView = DDLayout.views.RowView.extend({
    is_top_level_row : function () {
        return false;
    }
});