DDLayout.views.AccordionPanelView = DDLayout.views.TabsTabView.extend({

});