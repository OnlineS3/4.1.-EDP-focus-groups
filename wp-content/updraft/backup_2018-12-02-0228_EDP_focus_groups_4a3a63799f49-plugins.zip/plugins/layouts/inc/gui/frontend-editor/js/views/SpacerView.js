DDLayout.views.SpacerView = DDLayout.views.CellView.extend({
    defaultCssClass:'spacer'
});