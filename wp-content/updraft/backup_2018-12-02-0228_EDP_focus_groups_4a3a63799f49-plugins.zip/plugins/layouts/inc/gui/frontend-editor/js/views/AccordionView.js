DDLayout.views.AccordionView = DDLayout.views.ContainerView.extend({

});