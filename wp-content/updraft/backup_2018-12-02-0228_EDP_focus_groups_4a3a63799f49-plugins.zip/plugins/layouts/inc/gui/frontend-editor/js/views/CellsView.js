DDLayout.views.CellsView = DDLayout.views.abstract.CollectionView.extend({

});