<script type="text/html" id="tpl-toolset-frontend-container">
    <div class="ddl-frontend-editor-overlay ddl-frontend-editor-overlay-{{{ kind }}} ddl-frontend-editor-overlay-parent">
        <div class="ddl-block-overlay-header">
            <div class="ddl-block-overlay-title">{{{ kind }}}: {{{ name }}}</div>
        </div>
    </div>
</script>