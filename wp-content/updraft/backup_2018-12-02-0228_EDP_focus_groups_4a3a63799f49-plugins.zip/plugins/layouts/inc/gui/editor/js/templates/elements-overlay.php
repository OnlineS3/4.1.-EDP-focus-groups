<script type="text/html" id="ddl-elements-overlay">
    <div id="elements-overlay-{{{id}}}" class="ddl-elements-overlay js-ddl-elements-overlay">

    </div>
</script>