DDLayout = DDLayout || {};

DDLayout.PostLoopCell = function()
{
	var self = this;

	self.init = function()
	{
		// do something
	}

	self.init();
};