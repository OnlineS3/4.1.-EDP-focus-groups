<?php
// This is for an undefined cell
?>

<script type="text/html" id="undefined-template">
    <div class="cell-content">
    </div>

</script>

