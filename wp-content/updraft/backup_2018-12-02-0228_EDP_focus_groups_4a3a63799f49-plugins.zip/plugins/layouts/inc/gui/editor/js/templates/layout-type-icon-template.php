<script type="text/html" id="js-ddl-template-icon-layout-type">
	<div id="iconwrap" class="js-layouts-icon-wrap">
		<img src="<?php echo WPDDL_RES_RELPATH;?>/images/{{{icon}}}" class="js-layouts-icon layouts-icon" data-tooltip-content="{{{text}}}" data-tooltip-header="{{{header}}}" />
	</div>
</script>