<div class='ddl-layout-type-editor-wrap'>
<p><?php _e( 'If you want to design layouts for the entire page, you need to', 'ddl-layouts' );?><a target='_blank' href='<?php echo WPDLL_PARENT_LAYOUT;?>' ><?php _e(' integrate Layouts into the theme', 'ddl-layouts');?><i class='fa fa-external-link' aria-hidden='true' ></i></a></p>
</div>
