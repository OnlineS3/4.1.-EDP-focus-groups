<div id="ddl-error-page">

    <p><?php  _e('You attempted to edit an item that doesn’t exist. Perhaps it was deleted?',  'ddl-layouts'); ?></p>

</div>