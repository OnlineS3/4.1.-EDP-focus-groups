<?php // TODO: Move it to a separate file ?>
<div class="hidden">
	<div class="tutorial-video-bar js-tutorial-video-bar">
		<p class="tutorial-video-bar-name js-collapse-tutorial-video-bar js-play-tutorial-video">
			<span class="js-tutorial-video-name"></span>
			<i class="icon-play-circle fa fa-play-circle-o"></i>
		</p>
		<div class="tutorial-video-bar-content">
			<p class="tutorial-video-bar-desc js-tutorial-video-bar-desc">

			</p>
			<button class="button-secondary js-collapse-tutorial-video-bar"><?php _e('Hide', 'ddl-layouts'); ?></button>
		</div>
		<i class="fa fa-remove icon-remove js-close-tutorial-video-bar js-remove-video"></i>
		<i class="icon-facetime-video fa fa-video-camera js-show-tutorial-video-bar"></i>
	</div>
</div>
