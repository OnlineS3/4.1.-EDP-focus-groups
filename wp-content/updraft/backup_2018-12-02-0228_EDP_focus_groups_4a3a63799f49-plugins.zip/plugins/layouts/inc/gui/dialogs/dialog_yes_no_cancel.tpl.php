<div class="ddl-dialogs-container">

    <div class="ddl-dialog" id="ddl-yes-no-cancel">
        <div class="ddl-dialog-header">
            <h2 class="js-dialog-title">-</h2>
            <i class="fa fa-remove icon-remove js-dialog-close"></i>
        </div>

	<div class="ddl-dialog-content">
	</div>

	<div class="ddl-dialog-footer">
		<button class="button js-dialog-yes"><?php _e('Yes','ddl-layouts') ?></button>
		<button class="button js-dialog-no"><?php _e('No','ddl-layouts') ?></button>
		<button class="button button-primary js-dialog-close"><?php _e('Cancel','ddl-layouts') ?></button>
	</div>

</div>