<script type="text/html" id="js-info-box">
	<div class="toolset-help js-info-box ddl-info-box" data-cell-type="{{ type }}">
		<div class="toolset-help-content">
			<h2>{{ header }}</h2>
			<p>{{ content }}</p>
		</div>
		<div class="toolset-help-sidebar">
			<div class="toolset-help-sidebar-ico"></div>
		</div>
		<i class="fa fa-times-circle icon-remove-sign js-remove-info-box"></i>
	
	</div>
	
</script>