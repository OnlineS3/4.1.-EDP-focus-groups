<?php

class WPDDL_Shortcode_Option_Default
	extends WPDDL_Shortcode_Option_Abstract {
}