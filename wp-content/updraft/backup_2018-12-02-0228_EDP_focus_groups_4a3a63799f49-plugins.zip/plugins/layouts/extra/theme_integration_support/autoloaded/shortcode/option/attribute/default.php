<?php

class WPDDL_Shortcode_Option_Attribute_Default
	extends WPDDL_Shortcode_Option_Attribute_Abstract {
}