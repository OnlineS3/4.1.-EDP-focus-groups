<?php

// @todo comment
interface WPDDL_Cell_Interface {

	// called by integration class
	public function setup();

}