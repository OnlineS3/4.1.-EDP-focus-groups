<?php
/**
 * The template for displaying the footer with Layouts
 *
 */

	do_action( 'wpbootstrap_before_footer' );
	do_action( 'wpbootstrap_after_footer' );
	do_action( 'wpbootstrap_before_wp_footer' );
	wp_footer();
	do_action( 'wpbootstrap_after_wp_footer' );
	?>

	</body>
</html>