<?php

namespace ToolsetAdvancedExport\Gui;

use ToolsetAdvancedExport as e;


/**
 * A controller for the Import/Export page in the Tools menu.
 *
 * @since 1.0
 */
class Page_Tools extends Page_Import_Export {


}