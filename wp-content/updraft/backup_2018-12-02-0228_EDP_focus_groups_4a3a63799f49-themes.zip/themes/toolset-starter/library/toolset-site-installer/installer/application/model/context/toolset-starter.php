<?php


class TT_Context_Toolset_Starter extends TT_Context_Theme {
	const ID   = 'theme';

	public function redirections() {
		// no redirect for Toolset Starter
		return;
	}
}